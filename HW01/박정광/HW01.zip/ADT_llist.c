#include <stdio.h>
#include<string.h>
#include "ADT_llist.h"

LLIST* create_list()
{
	LLIST* list;
	list=(LLIST*)malloc(sizeof(LLIST));
	if(list)
	{
		list->front=NULL;
		list->rear=NULL;
		list->pos=NULL;
		list->count=0;
	}
	return list;
}
int add_node_at(LLIST* list,int index, void* data)
{
	NODE* new_node;
	new_node=(NODE*)malloc(sizeof(NODE));
	if(!new_node)
		return -1;

	if((list->count)<index)
		return 1;

	new_node->data_ptr=data;
	new_node->next=NULL;
	
	if(list->count==0)
	{
		list->front=new_node;
		list->rear=new_node;
		(list->count)++;
		return 1;
	}
	
	int iter_i=0;
	
	if(index==0)//front
	{
		new_node->next=list->front;
		list->front=new_node;
		(list->count)++;
		return 1;
	}
	
	iter_i++;
	list->pos=list->front;
	while(iter_i!=index)
	{
		list->pos=list->pos->next;
		iter_i++;
	}
	
	if(iter_i==list->count)//rear
	{
		list->pos->next=new_node;
		list->rear=new_node;
		(list->count)++;
		return 1;
	}
	else//front�� rear�� �ƴ� ��. �߰�.
	{
		new_node->next=list->pos->next;
		list->pos->next=new_node;
		(list->count)++;
		return 1;
	}
}


unsigned int find_data(LLIST* list,void* search)
{
	list->pos=list->front;
	int  i = 0;
	int c = 0;
	int* iter_i= &i; 
	int* count=&c;
	
	while(list->pos!=NULL)
	{
		if (!strcmp(list->pos->data_ptr, search)) //ã�����ϴ� �ܾ�� ��
		{
			c++; //�ߺ��ܾ� count
			printf("index: [%d] ", *iter_i); //��ġ ���
			count=find_again(list, search, count,iter_i); //�ߺ��ܾ ���� node���� �˻�
			printf("�� �ֽ��ϴ�.\n %d�� �ߺ��Ǿ����ϴ�.\n", *count); //���� count ���
			return 1;
		}
			
		else //ã�°� �ƴϸ� ���� node��
		{
			list->pos=list->pos->next;
			i++;
		}
	}
	if (list->pos==NULL) //�ƿ� ���� �ܾ �˻����� ��
		printf("i can't find it\n");
}

int* find_again(LLIST* list, void* search,int* count,int* iter_i)
{
	int c = *count;
	int i = *iter_i;
	list->pos = list->pos->next; //�˻��� �ܾ� ����node�� �̵�
	i++;
	while (list->pos != NULL)
	{
		if (!strcmp(list->pos->data_ptr, search))
		{
			c++;
			count = &c;
			printf(" index : [%d] ", *iter_i);
			count=find_again(list, search, count, iter_i);
			
		}
		else
		{
			list->pos = list->pos->next;
			i++;
			iter_i = &i;
		}
	}
	return count;
}
