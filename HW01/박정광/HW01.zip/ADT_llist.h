#ifndef ADT_LLIST
#define ADT_LLIST

#include <stdio.h>
#include <stdlib.h>


//list node
typedef struct node
{
	void* data_ptr;
	struct node* next;
}NODE;

//list
typedef struct llist
{
	int count;
	NODE* front;
	NODE* rear;
	NODE* pos;
	
}LLIST;

//operations;
LLIST* create_list();
int add_node_at(LLIST* list, int index, void* data);
unsigned int find_data(LLIST* list,void* search);
int* find_again(LLIST* list, void* search, int* count, int* iter_i);


#endif